// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'buyer_profile.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BuyerProfileImpl _$$BuyerProfileImplFromJson(Map<String, dynamic> json) =>
    _$BuyerProfileImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      phoneNumber: json['phoneNumber'] as String,
    );

Map<String, dynamic> _$$BuyerProfileImplToJson(_$BuyerProfileImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'phoneNumber': instance.phoneNumber,
    };
