// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dispatch_profile.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DispatchProfileImpl _$$DispatchProfileImplFromJson(
  Map<String, dynamic> json,
) => _$DispatchProfileImpl(
  id: json['id'] as String,
  vehicleNumberPlate: json['vehicleNumberPlate'] as String,
);

Map<String, dynamic> _$$DispatchProfileImplToJson(
  _$DispatchProfileImpl instance,
) => <String, dynamic>{
  'id': instance.id,
  'vehicleNumberPlate': instance.vehicleNumberPlate,
};
