// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'seller_profile.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SellerProfileImpl _$$SellerProfileImplFromJson(Map<String, dynamic> json) =>
    _$SellerProfileImpl(
      id: json['id'] as String,
      storeName: json['storeName'] as String,
    );

Map<String, dynamic> _$$SellerProfileImplToJson(_$SellerProfileImpl instance) =>
    <String, dynamic>{'id': instance.id, 'storeName': instance.storeName};
