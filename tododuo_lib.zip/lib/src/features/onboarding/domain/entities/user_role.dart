enum UserRole { buyer, seller, dispatcher }
